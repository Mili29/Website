<!DOCTYPE html>
<html>
<head>
	<title>contact</title>
	<link rel="stylesheet" type="text/css" href="coffeeshopcss.css">
</head>
<body style="background-image:url(2.jpg);background-repeat: no-repeat;background-size:cover;">
	<br><br><br><br><br><br>
	<ul>
		<li><a href="coffeshop.php">coffeshop</a></li>
		<li><a href="order.php">order</a></li>
		<li><a href="payment.php">payment</a></li>
		<li><a href="offer.php">offer</a></li>
		<li><a href="product.php">product</a></li>
		<li><a href="promotion.php">promotion</a></li>
		<li><a href="staff.php">staff</a></li>
		<li><a href="Data.php">Customer</a></li>
		<li><a href="contact.php">Contact</a></li>
		<li class="b"><a href="login.php">logout</a></li>
	</ul>
	<br><br>
	<h3 font-color="white">
		Mili Makwana<br>
		18BCE109<br>
		18bce109@nirmauni.ac.in<br><br><br>

		Labdhi Sheth<br>
		18BCE101<br>
		18bce101@nirmauni.ac.in<br><br><br>

		Divya Mahur<br>
		18BCE106<br>
		18bce106@nirmauni.ac.in<br><br><br>

	</h3>
</body>
</html>
